package JAKJ . RedstoneInMotion ;

public class TeleportativeSpectreTeleporter extends net . minecraft . world . Teleporter
{
	public TeleportativeSpectreTeleporter ( net . minecraft . world . World World )
	{
		super ( ( net . minecraft . world . WorldServer ) World ) ;
	}

	@Override
	public void placeInPortal ( net . minecraft . entity . Entity Entity , double X , double Y , double Z , float Yaw )
	{
	}
}
